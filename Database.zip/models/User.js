const { model, Schema } = require("mongoose")

const userSchema = new Schema({
    _id: {
        type: String,
        required: true
    },
    username: {
        type: String,
        required: true
    },
    afk: {
        type: Boolean,
        default: false,
        required: false
    },
    afkArgs: {
        type: String,
        required: false
    },
    manager: {
        type: Boolean,
        default: false,
        required: false
    },
    warn: {
        type: Number,
        default: 0,
        required: false
    },
    level: {
        type: Number,
        default: 0,
        required: false
    },
    xp: {
        type: Number,
        default: 0,
        required: false
    },
    money: {
        type: Number,
        default: 0,
        required: false
    },
    point: {
        type: Number,
        default: 0,
        required: false
    }
}, { versionKey: false });

module.exports = model("users", userSchema)